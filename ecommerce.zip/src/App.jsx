import React from "react";
// react-router-dom
import { BrowserRouter, Routes, Route } from "react-router-dom";
// pages
import { Home, ProductDetails } from "./pages";
// components
import { Sidebar, Header, Footer } from "./components";
import Demo from "./demo/Demo";

const App = () => {
  return (
    <div className="">
      <BrowserRouter>
        <Header />

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/product/:id" element={<ProductDetails />} />
          <Route path="/demo" element={<Demo />}></Route>
        </Routes>

        <Sidebar />
        <Footer />
      </BrowserRouter>
    </div>
  );
};

export default App;

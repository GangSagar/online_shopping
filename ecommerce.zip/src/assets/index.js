import Logo from "./logo.svg";
import bgHero from "./bg_hero.svg";
import WomenHero from "./woman_hero.png";

export { Logo, bgHero, WomenHero };

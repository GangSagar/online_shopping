import Home from "./Home";
import ProductDetails from "./ProductDetails";

export { Home, ProductDetails };

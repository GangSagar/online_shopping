import React, { useState } from "react";

const HoverEffect = () => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div className="group relative z-50" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
      {/* Div 1 */}
      <div className="bg-blue-500 p-4 cursor-pointer hover:bg-blue-700 transition duration-300">Hover me (Div 1)</div>

      {/* Div 2 */}
      <div className={`${isHovered ? "block" : "hidden"} absolute top-full left-0 bg-green-500 p-4`}>I appear when Div 1 is hovered (Div 2)</div>
    </div>
  );
};

export default HoverEffect;
